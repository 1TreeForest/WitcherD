#ifndef PHP_FLATFILE_H
#define PHP_FLATFILE_H

#if DBA_FLATFILE

#include "php_dba.h"

DBA_FUNCS(flatfile);

#endif

#endif
